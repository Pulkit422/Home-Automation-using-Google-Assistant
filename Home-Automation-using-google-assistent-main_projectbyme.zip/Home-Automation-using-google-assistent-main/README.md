# Home-Automation-using-google-assistent
Ths IOT based home automation using Google assistent may contain the sinric pro as a connecting software between the google home and the ESP8266 
